import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const escena = new THREE.Scene();
escena.background = new THREE.Color(0x030817);
escena.fog = new THREE.FogExp2(0x030817, 0.012);

const camara = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
camara.position.set(6, 5, 9);
camara.lookAt(0, 1.5, 0);

const renderizador = new THREE.WebGLRenderer({ antialias: true });
renderizador.setSize(window.innerWidth, window.innerHeight);
renderizador.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderizador.shadowMap.enabled = true;
renderizador.shadowMap.type = THREE.PCFSoftShadowMap;
renderizador.outputColorSpace = THREE.SRGBColorSpace;
document.body.appendChild(renderizador.domElement);

const controles = new OrbitControls(camara, renderizador.domElement);
controles.enableDamping = true;
controles.target.set(0, 1.5, 0);

// Nombre del personaje
const titulo = document.createElement('div');
titulo.textContent = 'PAIPA - ALIEN GUITARRISTA';
titulo.style.cssText = 'position:fixed;top:18px;left:20px;color:#45e68a;font:bold 25px Arial;text-shadow:0 0 12px #005030;z-index:10;';
document.body.appendChild(titulo);

const panel = document.createElement('div');
panel.style.cssText = 'position:fixed;top:60px;left:20px;padding:10px 14px;color:white;background:rgba(0,0,0,.65);border:1px solid #00cfff;border-radius:8px;font:13px Arial;line-height:1.6;z-index:10;';
document.body.appendChild(panel);

// Segunda cámara
const camaraSecundaria = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
camaraSecundaria.position.set(-7, 4, 8);
camaraSecundaria.lookAt(0, 2, 0);
let usarSegundaCamara = false;

escena.add(new THREE.AmbientLight(0xffffff, 1.2));

const luzPrincipal = new THREE.DirectionalLight(0xffffff, 2);
luzPrincipal.position.set(5, 8, 6);
luzPrincipal.castShadow = true;
escena.add(luzPrincipal);

const luzAzul = new THREE.PointLight(0x168cff, 100, 15);
luzAzul.position.set(-4, 3, 3);
escena.add(luzAzul);

const luzMorada = new THREE.PointLight(0xb52cff, 90, 15);
luzMorada.position.set(4, 4, -3);
escena.add(luzMorada);

// Plano cartesiano
escena.add(new THREE.AxesHelper(5));

const cuadricula = new THREE.GridHelper(20, 20, 0x7184b5, 0x35405f);
cuadricula.position.y = 0;
escena.add(cuadricula);

// MATERIALES
const verde = new THREE.MeshStandardMaterial({ color: 0x45e68a, roughness: 0.35, metalness: 0.05 });
const verdeOscuro = new THREE.MeshStandardMaterial({ color: 0x168b59, roughness: 0.4 });
const piel = new THREE.MeshStandardMaterial({ color: 0x63f5a0, roughness: 0.4 });
const negro = new THREE.MeshStandardMaterial({ color: 0x02030a, roughness: 0.12, metalness: 0.2 });
const brilloAzul = new THREE.MeshStandardMaterial({ color: 0x00cfff, emissive: 0x0088ff, emissiveIntensity: 1.5 });
const blanco = new THREE.MeshStandardMaterial({ color: 0xffffff });
const rojo = new THREE.MeshStandardMaterial({ color: 0xe32645, metalness: 0.65, roughness: 0.25 });
const metal = new THREE.MeshStandardMaterial({ color: 0xc4d3e8, metalness: 0.9, roughness: 0.2 });
const madera = new THREE.MeshStandardMaterial({ color: 0x9b5528, metalness: 0.25, roughness: 0.4 });

// FUNCIONES
function esfera(padre, material, posicion, escala) {
    const objeto = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 24), material);
    objeto.position.set(...posicion);
    objeto.scale.set(...escala);
    objeto.castShadow = true;
    objeto.receiveShadow = true;
    padre.add(objeto);
    return objeto;
}

function caja(padre, material, posicion, escala) {
    const objeto = new THREE.Mesh(new THREE.BoxGeometry(...escala), material);
    objeto.position.set(...posicion);
    objeto.castShadow = true;
    objeto.receiveShadow = true;
    padre.add(objeto);
    return objeto;
}

function cilindro(padre, material, inicio, fin, radio, segmentos = 16) {
    const a = new THREE.Vector3(...inicio);
    const b = new THREE.Vector3(...fin);
    const direccion = new THREE.Vector3().subVectors(b, a);

    const objeto = new THREE.Mesh(
        new THREE.CylinderGeometry(radio, radio, direccion.length(), segmentos),
        material
    );

    objeto.position.copy(a).add(b).multiplyScalar(0.5);
    objeto.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), direccion.normalize());
    objeto.castShadow = true;
    padre.add(objeto);
    return objeto;
}

// FONDO ESPACIAL
const estrellasGeometria = new THREE.BufferGeometry();
const posicionesEstrellas = [];

for (let i = 0; i < 1000; i++) {
    posicionesEstrellas.push(
        (Math.random() - 0.5) * 100,
        (Math.random() - 0.5) * 70,
        (Math.random() - 0.5) * 100
    );
}

estrellasGeometria.setAttribute('position', new THREE.Float32BufferAttribute(posicionesEstrellas, 3));

const estrellas = new THREE.Points(
    estrellasGeometria,
    new THREE.PointsMaterial({ color: 0xffffff, size: 0.09 })
);
escena.add(estrellas);

// Planeta azul
esfera(escena, new THREE.MeshStandardMaterial({
    color: 0x155bca,
    roughness: 0.7,
    emissive: 0x071c55
}), [-7, 5, -5], [2.2, 2.2, 2.2]);

// Planeta morado
const planeta = new THREE.Group();
planeta.position.set(7, 3, -7);
escena.add(planeta);

esfera(planeta, new THREE.MeshStandardMaterial({
    color: 0x7627c9,
    roughness: 0.5
}), [0, 0, 0], [1.5, 1.5, 1.5]);

const anillo = new THREE.Mesh(
    new THREE.TorusGeometry(2.1, 0.07, 12, 100),
    brilloAzul
);
anillo.rotation.x = Math.PI / 2.5;
planeta.add(anillo);

// PERSONAJE ALIEN
const alien = new THREE.Group();
escena.add(alien);

// Torso
esfera(alien, verdeOscuro, [0, 1.55, 0], [0.58, 0.72, 0.38]);

// Pecho
esfera(alien, verde, [0, 1.72, 0.29], [0.4, 0.38, 0.12]);

// Panel luminoso
esfera(alien, brilloAzul, [0, 1.75, 0.405], [0.13, 0.13, 0.04]);

// Cuello
cilindro(alien, verdeOscuro, [0, 2.05, 0], [0, 2.35, 0], 0.19);

// Cabeza
const cabeza = esfera(alien, verde, [0, 2.85, 0], [0.85, 0.78, 0.62]);

esfera(alien, verdeOscuro, [0, 2.48, 0.25], [0.53, 0.25, 0.42]);

// Ojos
esfera(alien, negro, [-0.38, 2.93, 0.51], [0.27, 0.37, 0.18]);
esfera(alien, negro, [0.38, 2.93, 0.51], [0.27, 0.37, 0.18]);

// Reflejos
esfera(alien, blanco, [-0.45, 3.08, 0.66], [0.075, 0.09, 0.035]);
esfera(alien, blanco, [0.31, 3.08, 0.66], [0.075, 0.09, 0.035]);

// Boca
esfera(alien, negro, [0, 2.62, 0.64], [0.22, 0.055, 0.04]);

// Antenas
cilindro(alien, verdeOscuro, [-0.35, 3.45, 0], [-0.55, 3.9, 0], 0.055);
cilindro(alien, verdeOscuro, [0.35, 3.45, 0], [0.55, 3.9, 0], 0.055);

esfera(alien, brilloAzul, [-0.55, 3.9, 0], [0.13, 0.13, 0.13]);
esfera(alien, brilloAzul, [0.55, 3.9, 0], [0.13, 0.13, 0.13]);
esfera(alien, brilloAzul, [0, 3.55, 0.25], [0.12, 0.12, 0.07]);

// PIERNAS
const piernaIzq = new THREE.Group();
piernaIzq.position.set(-0.3, 1.05, 0);
alien.add(piernaIzq);

cilindro(piernaIzq, verdeOscuro, [0, 0, 0], [-0.05, -0.55, 0], 0.17);
esfera(piernaIzq, verde, [-0.05, -0.55, 0], [0.18, 0.18, 0.18]);
esfera(piernaIzq, negro, [-0.05, -0.85, 0.12], [0.25, 0.13, 0.35]);

const piernaDer = new THREE.Group();
piernaDer.position.set(0.3, 1.05, 0);
alien.add(piernaDer);

cilindro(piernaDer, verdeOscuro, [0, 0, 0], [0.05, -0.55, 0], 0.17);
esfera(piernaDer, verde, [0.05, -0.55, 0], [0.18, 0.18, 0.18]);
esfera(piernaDer, negro, [0.05, -0.85, 0.12], [0.25, 0.13, 0.35]);

// GUITARRA
const guitarra = new THREE.Group();
alien.add(guitarra);

guitarra.position.set(0.05, 1.48, 0.72);
guitarra.rotation.z = -0.25;
guitarra.rotation.x = -0.12;

esfera(guitarra, rojo, [0, 0, 0], [0.48, 0.55, 0.16]);
esfera(guitarra, rojo, [-0.22, -0.2, 0.02], [0.28, 0.33, 0.16]);
esfera(guitarra, rojo, [0.22, 0.2, 0.02], [0.27, 0.32, 0.16]);

caja(guitarra, metal, [0, 0, 0.16], [0.36, 0.4, 0.035]);
caja(guitarra, madera, [0, 0.82, 0], [0.17, 1.25, 0.12]);
caja(guitarra, negro, [0, 0.82, 0.075], [0.14, 1.25, 0.035]);

// Trastes
for (let i = 0; i < 12; i++) {
    caja(guitarra, metal, [0, 0.27 + i * 0.1, 0.1], [0.15, 0.018, 0.018]);
}

// Cuerdas
for (let i = 0; i < 6; i++) {
    const x = -0.05 + i * 0.02;
    cilindro(guitarra, metal, [x, -0.3, 0.19], [x, 1.45, 0.12], 0.006, 6);
}

caja(guitarra, metal, [0, -0.3, 0.18], [0.27, 0.07, 0.045]);
caja(guitarra, negro, [0, -0.05, 0.19], [0.26, 0.08, 0.04]);
caja(guitarra, negro, [0, 0.15, 0.19], [0.26, 0.08, 0.04]);

esfera(guitarra, metal, [0.28, -0.28, 0.18], [0.055, 0.055, 0.04]);
esfera(guitarra, metal, [0.28, -0.12, 0.18], [0.055, 0.055, 0.04]);

esfera(guitarra, rojo, [0, 1.53, 0], [0.16, 0.18, 0.1]);

for (let i = 0; i < 3; i++) {
    esfera(guitarra, metal, [-0.17, 1.45 + i * 0.08, 0], [0.07, 0.035, 0.04]);
    esfera(guitarra, metal, [0.17, 1.45 + i * 0.08, 0], [0.07, 0.035, 0.04]);
}

// BRAZOS Y MANOS
esfera(alien, verdeOscuro, [-0.53, 1.95, 0], [0.22, 0.22, 0.22]);
cilindro(alien, piel, [-0.53, 1.95, 0], [-0.72, 1.95, 0.45], 0.14);
esfera(alien, verde, [-0.72, 1.95, 0.45], [0.16, 0.16, 0.16]);
cilindro(alien, piel, [-0.72, 1.95, 0.45], [-0.10, 2.27, 0.85], 0.12);
esfera(alien, piel, [-0.10, 2.27, 0.85], [0.19, 0.15, 0.13]);

for (let i = 0; i < 4; i++) {
    const x = -0.20 + i * 0.065;
    cilindro(alien, piel, [x, 2.30, 0.89], [x + 0.01, 2.22, 0.99], 0.035, 10);
}

cilindro(alien, piel, [-0.02, 2.27, 0.84], [-0.03, 2.19, 0.98], 0.04);

esfera(alien, verdeOscuro, [0.53, 1.95, 0], [0.22, 0.22, 0.22]);
cilindro(alien, piel, [0.53, 1.95, 0], [0.77, 1.78, 0.45], 0.14);
esfera(alien, verde, [0.77, 1.78, 0.45], [0.16, 0.16, 0.16]);
cilindro(alien, piel, [0.77, 1.78, 0.45], [0.28, 1.45, 0.91], 0.12);
esfera(alien, piel, [0.28, 1.45, 0.91], [0.2, 0.14, 0.13]);

for (let i = 0; i < 4; i++) {
    const x = 0.15 + i * 0.075;
    cilindro(alien, piel, [x, 1.43, 0.95], [x + 0.02, 1.34, 0.98], 0.035, 10);
}

cilindro(alien, piel, [0.17, 1.47, 0.91], [0.12, 1.38, 0.98], 0.04);

// CINTURÓN
caja(alien, negro, [0, 1.05, 0], [0.75, 0.12, 0.43]);
esfera(alien, brilloAzul, [-0.25, 1.05, 0.23], [0.06, 0.06, 0.03]);
esfera(alien, brilloAzul, [0.25, 1.05, 0.23], [0.06, 0.06, 0.03]);

// ANIMACIONES Y CONTROLES
const reloj = new THREE.Clock();

let saltando = false;
let inicioSalto = 0;
let bailando = false;
let sesgado = false;
const duracionSalto = 0.8;

document.addEventListener('keydown', (evento) => {
    const tecla = evento.key.toLowerCase();
    const paso = 0.15;

    switch (tecla) {

        // MOVIMIENTO
        case 'arrowup':
        case 'w':
            alien.position.z -= paso;
            break;

        case 'arrowdown':
        case 's':
            alien.position.z += paso;
            break;

        case 'arrowleft':
        case 'a':
            alien.position.x -= paso;
            break;

        case 'arrowright':
        case 'd':
            alien.position.x += paso;
            break;

        // ROTACIÓN
        case 'q':
            alien.rotation.y += 0.1;
            break;

        case 'e':
            alien.rotation.y -= 0.1;
            break;

        // TAMAÑO
        case '+':
        case '=':
            alien.scale.multiplyScalar(1.1);
            break;

        case '-':
            alien.scale.multiplyScalar(0.9);
            break;

        // SALTO
        case ' ':
            if (!saltando) {
                saltando = true;
                inicioSalto = reloj.getElapsedTime();
            }
            break;

        // BAILE
        case 'b':
            bailando = !bailando;
            break;

        // CAMBIAR CÁMARA
        case 'c':
            usarSegundaCamara = !usarSegundaCamara;
            controles.enabled = !usarSegundaCamara;
            break;

        // SESGADO
        case 'g':
            sesgado = !sesgado;
            break;

        // RESTABLECER
        case 'r':
            alien.position.set(0, 0, 0);
            alien.rotation.set(0, 0, 0);
            alien.scale.set(1, 1, 1);
            saltando = false;
            bailando = false;
            sesgado = false;
            break;
    }
});



// Matriz para aplicar el sesgado
alien.matrixAutoUpdate = false;
const matrizBase = new THREE.Matrix4();
const matrizSesgado = new THREE.Matrix4();

function animar() {
    const tiempo = reloj.getElapsedTime();

    // Salto animado
    const elevacion = saltando
        ? Math.sin(Math.min((tiempo - inicioSalto) / duracionSalto, 1) * Math.PI) * 1.5
        : 0;

    if (saltando && tiempo - inicioSalto >= duracionSalto) {
        saltando = false;
    }

    alien.position.y = elevacion + Math.sin(tiempo * 2) * 0.025;

    // Movimiento de cabeza
    cabeza.rotation.y = Math.sin(tiempo * 1.5) * 0.08;

    // Escenario espacial
    planeta.rotation.y = tiempo * 0.15;
    estrellas.rotation.y = tiempo * 0.005;

    // Guitarra
    guitarra.rotation.y = Math.sin(tiempo * 3) * 0.035;

    // BAILE con tecla B
    if (bailando) {
        alien.rotation.z = Math.sin(tiempo * 5) * 0.12;
        guitarra.rotation.y = Math.sin(tiempo * 6) * 0.13;
        piernaIzq.rotation.x = Math.sin(tiempo * 5) * 0.35;
        piernaDer.rotation.x = -Math.sin(tiempo * 5) * 0.35;
        cabeza.rotation.z = Math.sin(tiempo * 5) * 0.07;
    } else {
        alien.rotation.z = 0;
        piernaIzq.rotation.x = 0;
        piernaDer.rotation.x = 0;
        cabeza.rotation.z = 0;
    }

    // SESGADO con tecla G
    matrizBase.compose(alien.position, alien.quaternion, alien.scale);
    matrizSesgado.set(
        1, sesgado ? 0.18 * Math.sin(tiempo * 5) : 0, 0, 0,
        0, 1, 0, 0,
        0, 0, 1, 0,
        0, 0, 0, 1
    );

    alien.matrix.copy(matrizBase).multiply(matrizSesgado);
    alien.matrixWorldNeedsUpdate = true;

    // Segunda cámara que sigue al personaje
    camaraSecundaria.position.set(
        alien.position.x - 7,
        alien.position.y + 4,
        alien.position.z + 8
    );

    camaraSecundaria.lookAt(
        alien.position.x,
        alien.position.y + 2,
        alien.position.z
    );

    panel.innerHTML = `
        <b>PAIPA - ALIEN GUITARRISTA</b><br>
        Flechas: mover | Q/E: girar<br>
        + / -: tamaño | ESPACIO: brincar<br>
        B: baile (${bailando ? 'ACTIVADO' : 'apagado'})<br>
        C: cámara (${usarSegundaCamara ? 'secundaria' : 'principal'})<br>
        G: sesgado (${sesgado ? 'ACTIVADO' : 'apagado'})<br>
        R: restablecer personaje
    `;

    controles.update();
    renderizador.render(escena, usarSegundaCamara ? camaraSecundaria : camara);
}

renderizador.setAnimationLoop(animar);

// AJUSTAR TAMAÑO DE PANTALLA
window.addEventListener('resize', () => {
    camara.aspect = window.innerWidth / window.innerHeight;
    camara.updateProjectionMatrix();

    camaraSecundaria.aspect = window.innerWidth / window.innerHeight;
    camaraSecundaria.updateProjectionMatrix();

    renderizador.setSize(window.innerWidth, window.innerHeight);
});